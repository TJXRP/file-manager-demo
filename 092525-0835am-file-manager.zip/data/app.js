// app.js - FlipBook Logic
// All features: book loading, navigation, bookmarks, notes, share, download, print

const BOOK_JSON = "book.pages.json";
const BOOKMARKS_KEY = "flipbook_bookmarks";
const NOTES_KEY = "flipbook_notes";
const READ_PAGES_KEY = "flipbook_read_pages";

let book = { title: "", author: "", pages: [] };
let currentPage = 0;
let bookmarks = [];
let notes = {};
let readPages = [];

// DOM Elements
const pageContent = document.getElementById("page-content");
const pageIndicator = document.getElementById("page-indicator");
const pageIndicatorBottom = document.getElementById("page-indicator-bottom");
const nextBtn = document.getElementById("next-page");
const prevBtn = document.getElementById("prev-page");
const randomBtn = document.getElementById("random-page");
const addBookmarkBtn = document.getElementById("add-bookmark");
const bookmarksList = document.getElementById("bookmarks-list");
const noteInput = document.getElementById("note-input");
const saveNoteBtn = document.getElementById("save-note");
const notesList = document.getElementById("notes-list");
const shareBtn = document.getElementById("share-btn");
const printBtn = document.getElementById("print-btn");
const bookTitle = document.getElementById("book-title");
const prevBtnTop = document.getElementById("prev-page-top");
const nextBtnTop = document.getElementById("next-page-top");
const randomBtnTop = document.getElementById("random-page-top");
const fullscreenBtn = document.getElementById("fullscreen-btn");
const discordBtn = document.getElementById("discord-btn");
const downloadTxtBtn = document.getElementById("download-txt");
const downloadPdfBtn = document.getElementById("download-pdf");
const downloadMdBtn = document.getElementById("download-md");
const firstBtnTop = document.getElementById("first-page-top");
const lastBtnTop = document.getElementById("last-page-top");
const firstBtn = document.getElementById("first-page");
const lastBtn = document.getElementById("last-page");

// Utility: Load JSON
function loadBook() {
  fetch(BOOK_JSON)
    .then((res) => {
      if (!res.ok) throw new Error("Book file not found or inaccessible");
      return res.json();
    })
    .then((data) => {
      book = data;
      if (bookTitle) bookTitle.textContent = book.title || "FlipBook";
      renderPage(0);
      loadBookmarks();
      loadNotes();
      loadReadPages();
      renderBookmarks();
      renderNotes();
    })
    .catch((err) => {
      if (pageContent)
        pageContent.textContent = "Failed to load book. " + err.message;
    });
}

// Page Navigation
function renderPage(idx) {
  if (idx < 0 || idx >= book.pages.length) return;
  currentPage = idx;
  pageContent.textContent = book.pages[idx];
  pageIndicator.textContent = `Page ${idx + 1} of ${book.pages.length}`;
  pageIndicatorBottom.textContent = `Page ${idx + 1} of ${book.pages.length}`;
  markPageRead(idx);
  renderBookmarks();
  renderNotes();
  updateBookmarkHighlight();
  updateNoteInput();
}
function nextPage() {
  if (currentPage < book.pages.length - 1) renderPage(currentPage + 1);
}
function prevPage() {
  if (currentPage > 0) renderPage(currentPage - 1);
}
function randomPage() {
  const idx = Math.floor(Math.random() * book.pages.length);
  renderPage(idx);
}
function firstPage() {
  renderPage(0);
}
function lastPage() {
  renderPage(book.pages.length - 1);
}

// Bookmarks
function loadBookmarks() {
  bookmarks = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
}
function saveBookmarks() {
  localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(bookmarks));
}
function addBookmark() {
  if (!bookmarks.includes(currentPage)) {
    bookmarks.push(currentPage);
    saveBookmarks();
    renderBookmarks();
  }
}
function removeBookmark(idx) {
  bookmarks = bookmarks.filter((b) => b !== idx);
  saveBookmarks();
  renderBookmarks();
}
function renderBookmarks() {
  bookmarksList.innerHTML = "";
  bookmarks.forEach((idx) => {
    const li = document.createElement("li");
    li.textContent = `Page ${idx + 1}`;
    if (readPages.includes(idx)) li.classList.add("bookmark-read");
    if (idx === currentPage) li.classList.add("bookmark-current");
    const jumpBtn = document.createElement("button");
    jumpBtn.textContent = "Go";
    jumpBtn.onclick = () => renderPage(idx);
    const removeBtn = document.createElement("button");
    removeBtn.textContent = "✕";
    removeBtn.onclick = () => removeBookmark(idx);
    li.append(jumpBtn, removeBtn);
    bookmarksList.appendChild(li);
  });
}
function updateBookmarkHighlight() {
  // Visually indicate current page in bookmarks
  Array.from(bookmarksList.children).forEach((li) => {
    li.classList.toggle(
      "bookmark-current",
      li.textContent.includes(`Page ${currentPage + 1}`)
    );
  });
}

// Read Pages
function loadReadPages() {
  readPages = JSON.parse(localStorage.getItem(READ_PAGES_KEY) || "[]");
}
function saveReadPages() {
  localStorage.setItem(READ_PAGES_KEY, JSON.stringify(readPages));
}
function markPageRead(idx) {
  if (!readPages.includes(idx)) {
    readPages.push(idx);
    saveReadPages();
  }
}

// Notes
function loadNotes() {
  notes = JSON.parse(localStorage.getItem(NOTES_KEY) || "{}");
}
function saveNotes() {
  localStorage.setItem(NOTES_KEY, JSON.stringify(notes));
}
function addNote() {
  const text = noteInput.value.trim();
  if (text) {
    notes[currentPage] = text;
    saveNotes();
    renderNotes();
    updateNoteInput();
  }
}
function removeNote(idx) {
  delete notes[idx];
  saveNotes();
  renderNotes();
  updateNoteInput();
}
function renderNotes() {
  notesList.innerHTML = "";
  Object.keys(notes).forEach((idx) => {
    const li = document.createElement("li");
    li.textContent = `Page ${parseInt(idx) + 1}: ${notes[idx]}`;
    const removeBtn = document.createElement("button");
    removeBtn.textContent = "✕";
    removeBtn.onclick = () => removeNote(idx);
    li.appendChild(removeBtn);
    notesList.appendChild(li);
  });
}
function updateNoteInput() {
  noteInput.value = notes[currentPage] || "";
}

// Share
function sharePage() {
  const url = `${location.origin}${location.pathname}?page=${currentPage + 1}`;
  const text = `Check out this page in FlipBook: Page ${currentPage + 1}`;
  if (navigator.share) {
    navigator.share({ title: book.title, text, url });
  } else {
    navigator.clipboard.writeText(url);
    alert("Link copied to clipboard!");
  }
}

// Download Receipt
function downloadReceipt() {
  const receipt = `FlipBook Reading Receipt\nBook: ${book.title}\nAuthor: ${
    book.author
  }\nRead Pages: ${readPages
    .map((i) => i + 1)
    .join(", ")}\nBookmarks: ${bookmarks
    .map((i) => i + 1)
    .join(", ")}\nNotes: ${Object.entries(notes)
    .map(([i, n]) => `Page ${parseInt(i) + 1}: ${n}`)
    .join("; ")}\nDate: ${new Date().toLocaleString()}`;
  const blob = new Blob([receipt], { type: "text/plain" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "flipbook_receipt.txt";
  a.click();
}

// Print
function printBook() {
  let printContent = `<h1>${book.title}</h1>`;
  book.pages.forEach((p, i) => {
    printContent += `<h2>Page ${i + 1}</h2><p>${p}</p>`;
  });
  const win = window.open("", "", "width=800,height=600");
  win.document.write(
    `<html><head><title>${book.title}</title></head><body>${printContent}</body></html>`
  );
  win.document.close();
  win.print();
}

// Event Listeners
nextBtn.onclick = nextPage;
prevBtn.onclick = prevPage;
randomBtn.onclick = randomPage;
addBookmarkBtn.onclick = addBookmark;
saveNoteBtn.onclick = addNote;
shareBtn.onclick = sharePage;
printBtn.onclick = printBook;

// Top navigation
if (prevBtnTop && nextBtnTop && randomBtnTop && firstBtnTop && lastBtnTop) {
  firstBtnTop.onclick = firstPage;
  prevBtnTop.onclick = prevPage;
  nextBtnTop.onclick = nextPage;
  lastBtnTop.onclick = lastPage;
  randomBtnTop.onclick = randomPage;
}

// Fullscreen
if (fullscreenBtn) {
  fullscreenBtn.onclick = () => {
    const elem = document.documentElement;
    if (!document.fullscreenElement) {
      elem.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
  };
}

// Discord share
if (discordBtn) {
  discordBtn.onclick = () => {
    const url = `${location.origin}${location.pathname}?page=${
      currentPage + 1
    }`;
    const text = `Check out this page in FlipBook: Page ${currentPage + 1}`;
    const discordShareUrl = `https://discord.com/channels/@me?text=${encodeURIComponent(
      text + " " + url
    )}`;
    window.open(discordShareUrl, "_blank");
  };
}

// Download formats
function downloadFile(type) {
  let content = "";
  let filename = "";
  if (type === "txt") {
    content = book.pages.join("\n\n");
    filename = "flipbook.txt";
  } else if (type === "md") {
    content =
      `# ${book.title}\n\n` +
      book.pages.map((p, i) => `## Page ${i + 1}\n${p}`).join("\n\n");
    filename = "flipbook.md";
  } else if (type === "pdf") {
    // Simple PDF using browser print
    printBook();
    return;
  }
  if (type !== "pdf") {
    const blob = new Blob([content], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
  }
}
if (downloadTxtBtn) downloadTxtBtn.onclick = () => downloadFile("txt");
if (downloadMdBtn) downloadMdBtn.onclick = () => downloadFile("md");
if (downloadPdfBtn) downloadPdfBtn.onclick = () => downloadFile("pdf");

// On Load
window.onload = loadBook;

// Handle page param in URL
(function handlePageParam() {
  const params = new URLSearchParams(location.search);
  const page = parseInt(params.get("page"));
  if (!isNaN(page) && page > 0 && page <= book.pages.length) {
    renderPage(page - 1);
  }
})();

// End of app.js
