const fileInput = document.getElementById('fileInput');
const fileList = document.getElementById('fileList');
const editorSection = document.getElementById('editorSection');
const editor = document.getElementById('editor');
const filenameDisplay = document.getElementById('filenameDisplay');

let currentFile = '';

function refreshFiles() {
  fetch('files/')
    .then(res => res.json())
    .then(data => {
      fileList.innerHTML = '';
      data.files.forEach(file => {
        const div = document.createElement('div');
        div.className = 'file-item';
        div.innerHTML = `
          <span>${file}</span>
          <span>
            <button onclick="openFile('${file}')">✏️ Edit</button>
            <button onclick="downloadFile('${file}')">⬇️</button>
          </span>
        `;
        fileList.appendChild(div);
      });
    });
}

function uploadFiles() {
  const files = fileInput.files;
  Array.from(files).forEach(file => {
    const formData = new FormData();
    formData.append('file', file);
    fetch('upload.php', { method: 'POST', body: formData })
      .then(() => refreshFiles());
  });
}

function openFile(filename) {
  fetch(`files/${encodeURIComponent(filename)}`)
    .then(res => res.text())
    .then(content => {
      editor.value = content;
      filenameDisplay.textContent = filename;
      currentFile = filename;
      editorSection.style.display = 'block';
    });
}

function saveFile() {
  fetch('save.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: currentFile,
      content: editor.value
    })
  }).then(() => alert('File saved!'));
}

function deleteFile() {
  if (!confirm('Are you sure you want to delete this file?')) return;
  fetch(`delete.php?name=${encodeURIComponent(currentFile)}`, {
    method: 'DELETE'
  }).then(() => {
    closeEditor();
    refreshFiles();
  });
}

function closeEditor() {
  editorSection.style.display = 'none';
  editor.value = '';
  filenameDisplay.textContent = '';
  currentFile = '';
}

refreshFiles();
